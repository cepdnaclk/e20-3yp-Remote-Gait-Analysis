from app.services.sqs_consumer import poll_sqs

if __name__ == "__main__":
    poll_sqs()
